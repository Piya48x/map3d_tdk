// Presentation data only. These rooms do not become editor objects or alter the locked layout.
// Rectangles use local footprint coordinates: u left-to-right, v rear-to-entrance.
const zone = (id, name, kind, rect, detail) => ({ id, name, kind, rect, detail });

export const BUILDING_INTERIORS = Object.freeze({
    main_office: {
        title: 'Main Office', subtitle: 'พื้นที่สำนักงานกลางขนาดใหญ่',
        zones: [
            zone('md-room', 'MD Room', 'office', [.06, .08, .24, .18], 'ห้องทำงานผู้บริหาร (Managing Director)'),
            zone('meeting-1', 'Meeting Room 1', 'meeting', [.06, .29, .24, .16], 'ห้องประชุมย่อย 1'),
            zone('meeting-2', 'Meeting Room 2', 'meeting', [.06, .48, .24, .16], 'ห้องประชุมย่อย 2'),
            zone('main-office', 'Main Office', 'office', [.34, .08, .60, .56], 'พื้นที่สำนักงานกลางขนาดใหญ่'),
            zone('reception-security', 'Reception / Security', 'service', [.06, .68, .54, .24], 'พื้นที่ต้อนรับและจุดตรวจด้านหน้าบริเวณทางเข้า'),
            zone('restrooms', 'Restrooms', 'service', [.64, .68, .30, .24], 'ห้องน้ำชาย/หญิงบริเวณทางขึ้นลงบันได')
        ]
    },
    canteen: {
        title: 'Canteen', subtitle: 'โรงอาหารและส่วนสนับสนุน',
        zones: [
            zone('dining', 'Canteen', 'dining', [.07, .12, .58, .8], 'พื้นที่รับประทานอาหารตามภาพอ้างอิง'),
            zone('serving', 'จุดบริการอาหาร', 'service', [.69, .12, .24, .43], 'แนวเคาน์เตอร์บริการ'),
            zone('support-office', 'Office', 'office', [.69, .59, .24, .33], 'สำนักงานย่อยที่อยู่ติดกับ Canteen ในภาพ')
        ]
    },
    doke1_west: {
        title: 'Doke 1 · Production', subtitle: 'โซนผลิตด้านบน',
        zones: [
            zone('maintenance', 'Maintenance', 'service', [.08, .06, .38, .13], 'พื้นที่ซ่อมบำรุง'),
            zone('die-set', 'DIE-SET', 'service', [.08, .22, .38, .18], 'โซนจัดเตรียมแม่พิมพ์'),
            zone('top-line', 'Top-Line', 'line', [.51, .07, .41, .17], 'สายการผลิต Top-Line'),
            zone('spot-line', 'Spot-Line', 'line', [.51, .27, .41, .17], 'สายการผลิต Spot-Line'),
            zone('a-k-line', 'A-Line / K-Line', 'line', [.08, .46, .84, .2], 'สายการผลิต A-Line และ K-Line'),
            zone('c-line', 'C-Line', 'line', [.08, .69, .84, .23], 'สายการผลิต C-Line')
        ]
    },
    doke1_store: {
        title: 'Doke 1 · Store', subtitle: 'คลังและโซนผลิตต่อเนื่อง',
        zones: [
            zone('pd-team', 'Office PD Team', 'office', [.07, .07, .38, .14], 'สำนักงานทีม PD'),
            zone('spare', 'Spare Room', 'storage', [.5, .07, .43, .14], 'ห้องอะไหล่'),
            zone('h-line', 'H-Line / I-Line', 'line', [.07, .24, .86, .17], 'สายการผลิต H-Line และ I-Line'),
            zone('store', 'Store', 'storage', [.07, .44, .39, .46], 'พื้นที่จัดเก็บวัสดุและชิ้นงาน'),
            zone('rear-home', 'Assy Rear Home', 'line', [.5, .44, .43, .19], 'โซนประกอบ Assy Rear Home'),
            zone('coating-1', 'Coating 1', 'coating', [.5, .66, .43, .24], 'โซน Coating 1')
        ]
    },
    doke2_assy: {
        title: 'Doke 2 · Assembly', subtitle: 'K-Line, Coating 2 และ Assy Hanon',
        zones: [
            zone('k-line', 'K-Line', 'line', [.07, .08, .53, .47], 'สายการผลิต K-Line และเครื่องจักรตามผัง'),
            zone('coating-2', 'Coating 2', 'coating', [.64, .08, .29, .47], 'โซน Coating 2'),
            zone('assy-hanon', 'Assy Hanon', 'line', [.07, .59, .53, .31], 'โซนประกอบ Assy Hanon'),
            zone('hanon-store', 'Hanon Store', 'storage', [.64, .59, .29, .15], 'พื้นที่เก็บชิ้นงาน Hanon'),
            zone('maintenance-store', 'Maintenance Store', 'storage', [.64, .77, .29, .13], 'พื้นที่เก็บงานซ่อมบำรุง')
        ]
    },
    rack_dome: {
        title: 'Rack Dome', subtitle: 'พื้นที่จัดเก็บและเตรียมวัสดุ',
        zones: [
            zone('rack-a', 'Storage Rack A', 'storage', [.08, .09, .38, .38], 'แร็คจัดเก็บวัสดุฝั่ง A'),
            zone('rack-b', 'Storage Rack B', 'storage', [.54, .09, .38, .38], 'แร็คจัดเก็บวัสดุฝั่ง B'),
            zone('staging', 'Material Staging', 'service', [.08, .57, .84, .34], 'พื้นที่พักและเตรียมวัสดุ')
        ]
    }
});

const COLORS = {
    office: { floor: 0xe0eff9, accent: 0x2886bd, equipment: 0x537e9a },
    meeting: { floor: 0xd9e4f5, accent: 0x6565b5, equipment: 0x697c9d },
    dining: { floor: 0xf5ead5, accent: 0xcf9045, equipment: 0xa57648 },
    service: { floor: 0xe0eee6, accent: 0x419276, equipment: 0x638578 },
    storage: { floor: 0xe4e8ee, accent: 0x637d9e, equipment: 0x60748a },
    line: { floor: 0xe3f1e4, accent: 0x389c60, equipment: 0x517a6b },
    coating: { floor: 0xf5e8df, accent: 0xd27a51, equipment: 0x8d6659 }
};

export function createBuildingInterior(THREE, building, scale) {
    const plan = BUILDING_INTERIORS[building.id];
    if (!plan) return null;
    const w = building.size.width * scale;
    const d = building.size.depth * scale;
    const root = new THREE.Group();
    root.name = `Interior presentation · ${building.id}`;
    const geometry = new THREE.BoxGeometry(1, 1, 1);
    const materials = new Map();
    const textures = [];
    const pickables = [];
    const highlights = new Map();
    const mat = (color, roughness = .78) => {
        const key = `${color}-${roughness}`;
        if (!materials.has(key)) materials.set(key, new THREE.MeshStandardMaterial({ color, roughness }));
        return materials.get(key);
    };
    const box = (parent, x, y, z, width, height, depth, material) => {
        const mesh = new THREE.Mesh(geometry, material);
        mesh.position.set(x, y, z);
        mesh.scale.set(width, height, depth);
        mesh.receiveShadow = true;
        parent.add(mesh);
        return mesh;
    };
    const floorY = .55;
    box(root, 0, .15, 0, w + .9, .3, d + .9, mat(0x173950));
    const circulationColor = building.id === 'main_office' || building.id === 'canteen'
        ? 0xeaf0f1 : 0x8bc89a;
    box(root, 0, .38, 0, w, .16, d, mat(circulationColor));
    // A low edge keeps the cutaway readable while leaving every zone visible.
    for (const side of [-1, 1]) {
        box(root, side * w / 2, 1.22, 0, .22, 1.42, d, mat(0xb8cbd4));
        box(root, 0, 1.22, side * d / 2, w, 1.42, .22, mat(0xb8cbd4));
    }
    const label = (name, width, height) => {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 128;
        const ctx = canvas.getContext('2d');
        ctx.clearRect(0, 0, 512, 128);
        ctx.fillStyle = '#16354a';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = `700 ${name.length > 17 ? 31 : 40}px Arial, sans-serif`;
        ctx.fillText(name, 256, 66, 480);
        const texture = new THREE.CanvasTexture(canvas);
        texture.colorSpace = THREE.SRGBColorSpace;
        textures.push(texture);
        const mesh = new THREE.Mesh(new THREE.PlaneGeometry(width, height),
            new THREE.MeshBasicMaterial({ map: texture, transparent: true, depthWrite: false, side: THREE.DoubleSide }));
        mesh.rotation.x = -Math.PI / 2;
        return mesh;
    };
    plan.zones.forEach((item, index) => {
        const [u, v, uw, vd] = item.rect;
        const zw = w * uw;
        const zd = d * vd;
        const x = -w / 2 + w * (u + uw / 2);
        const z = -d / 2 + d * (v + vd / 2);
        const palette = COLORS[item.kind];
        const zoneGroup = new THREE.Group();
        zoneGroup.name = `Interior zone · ${item.id}`;
        zoneGroup.userData.interiorZone = item.id;
        zoneGroup.position.set(x, 0, z);
        root.add(zoneGroup);
        const tile = box(zoneGroup, 0, floorY, 0, zw - .16, .12, zd - .16, mat(palette.floor));
        tile.userData.interiorZone = item.id;
        pickables.push(tile);
        const highlight = box(zoneGroup, 0, floorY + .08, 0, zw - .3, .055, zd - .3, mat(palette.accent));
        highlight.visible = false;
        highlights.set(item.id, highlight);
        const edge = .09;
        for (const side of [-1, 1]) {
            box(zoneGroup, side * (zw / 2 - edge), .66, 0, edge, .2, zd, mat(palette.accent));
            box(zoneGroup, 0, .66, side * (zd / 2 - edge), zw, .2, edge, mat(palette.accent));
        }
        const labelMesh = label(item.name, Math.min(zw * .84, 14), Math.min(zd * .28, 3.1));
        labelMesh.position.set(0, .79, -zd * .28);
        zoneGroup.add(labelMesh);
        // Distinct silhouettes help visitors read the purpose of each area at a glance.
        const equipment = mat(palette.equipment);
        const metal = mat(0xc6d7de, .45);
        const dark = mat(0x304b5d);
        const count = Math.max(2, Math.min(8, Math.floor(zw / 3.8)));
        const step = (zw - 1.8) / count;
        if (item.kind === 'storage') {
            const rows = zd > 9 ? [-zd * .14, zd * .18] : [zd * .1];
            for (const row of rows) {
                for (let i = 0; i < count; i++) {
                    const px = (i - (count - 1) / 2) * step;
                    box(zoneGroup, px, 1.05, row, Math.max(.48, step * .7), .65,
                        Math.min(1.35, zd * .18), equipment);
                    box(zoneGroup, px, 1.42, row, Math.max(.48, step * .72), .08,
                        Math.min(1.4, zd * .19), metal);
                    box(zoneGroup, px, 1.72, row, Math.max(.48, step * .55), .47,
                        Math.min(1.1, zd * .14), i % 2 ? equipment : mat(0x8cabb9));
                }
            }
        } else if (item.kind === 'line') {
            const beltDepth = Math.min(1.4, zd * .2);
            box(zoneGroup, 0, .98, zd * .13, zw * .78, .28, beltDepth, dark);
            box(zoneGroup, 0, 1.16, zd * .13, zw * .76, .06, beltDepth * .78, metal);
            for (let i = 0; i < count; i++) {
                const px = (i - (count - 1) / 2) * step;
                box(zoneGroup, px, 1.05, zd * .13 - beltDepth * .7, Math.max(.4, step * .56), .72,
                    Math.min(1.1, zd * .13), equipment);
                box(zoneGroup, px, 1.42, zd * .13 - beltDepth * .7, Math.max(.4, step * .48), .06,
                    Math.min(1.1, zd * .13), metal);
                box(zoneGroup, px, .77, zd * .13 + beltDepth * .78, .16, .26, .16, mat(0xf2bd52));
            }
        } else if (item.kind === 'coating') {
            const depth = Math.min(zd * .42, 5.2);
            box(zoneGroup, 0, .97, zd * .12, zw * .78, .54, depth, equipment);
            box(zoneGroup, 0, 1.29, zd * .12, zw * .8, .12, depth * .72, metal);
            for (let i = 0; i < count; i++) {
                const px = (i - (count - 1) / 2) * step;
                box(zoneGroup, px, 1.38, zd * .12, .18, .07, depth * .7, mat(0xe7a16f));
            }
            box(zoneGroup, 0, .72, zd * .12 + depth * .62, zw * .7, .07, .1, mat(0xd27a51));
        } else if (item.kind === 'dining') {
            const columns = Math.min(5, count);
            for (let i = 0; i < columns; i++) {
                const px = (i - (columns - 1) / 2) * ((zw - 1.8) / columns);
                for (const row of (zd > 9 ? [-zd * .06, zd * .24] : [zd * .12])) {
                    box(zoneGroup, px, .94, row, Math.max(.7, step * .52), .12, 1.15, equipment);
                    for (const side of [-1, 1]) box(zoneGroup, px, .73, row + side * .86,
                        Math.max(.65, step * .45), .2, .28, metal);
                }
            }
        } else if (item.kind === 'meeting') {
            box(zoneGroup, 0, .95, zd * .12, zw * .62, .14, Math.min(1.8, zd * .27), equipment);
            for (let i = 0; i < Math.min(6, count + 2); i++) {
                const px = (i - (Math.min(6, count + 2) - 1) / 2) * (zw * .58 / Math.min(6, count + 2));
                for (const side of [-1, 1]) box(zoneGroup, px, .78, zd * .12 + side * Math.min(1.4, zd * .2),
                    .45, .36, .48, metal);
            }
        } else if (item.kind === 'office') {
            for (let i = 0; i < count; i++) {
                const px = (i - (count - 1) / 2) * step;
                const row = zd * .12 + (i % 2) * .25;
                box(zoneGroup, px, .93, row, Math.max(.55, step * .63), .13, Math.min(1.05, zd * .16), equipment);
                box(zoneGroup, px, 1.17, row - .22, .52, .34, .08, dark);
                box(zoneGroup, px, .76, row + .78, .46, .3, .42, metal);
            }
        } else {
            box(zoneGroup, 0, .94, zd * .14, zw * .7, .42, Math.min(1.7, zd * .25), equipment);
            box(zoneGroup, 0, 1.19, zd * .14, zw * .72, .08, Math.min(1.8, zd * .26), metal);
        }
        if (index % 2 === 0 && zd > 8) box(zoneGroup, 0, .7, zd * .32, zw * .62, .06, .08, mat(0xffffff));
    });
    return {
        root, plan, pickables,
        setSelected(id) { highlights.forEach((mesh, key) => { mesh.visible = key === id; }); },
        dispose() {
            root.traverse(object => {
                if (object.geometry && object.geometry !== geometry) object.geometry.dispose();
                if (object.material && ![...materials.values()].includes(object.material)) object.material.dispose();
            });
            geometry.dispose();
            materials.forEach(material => material.dispose());
            textures.forEach(texture => texture.dispose());
        }
    };
}
